class Note < ActiveRecord::Base
end
